Shared constants
