Cleanup background job placeholder
