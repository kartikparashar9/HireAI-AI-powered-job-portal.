Pagination helper
