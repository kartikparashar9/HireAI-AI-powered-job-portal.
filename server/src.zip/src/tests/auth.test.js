Auth tests placeholder
