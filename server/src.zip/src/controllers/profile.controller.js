import { useEffect, useMemo, useState } from "react";
import { useDispatch, useSelector } from "react-redux";

import {
  fetchRecruiterProfile,
  createRecruiterProfile,
  updateRecruiterProfile,
  clearRecruiterError,
  clearRecruiterSuccess,
} from "../recruiterSlice";

import "../recruiter.css";

// =====================================================
// INITIAL FORM
// =====================================================

const emptyForm = {
  phone: "",
  headline: "",
  about: "",
  location: "",

  skills: [],

  experience: [],

  education: [],

  socialLinks: {
    linkedin: "",
    github: "",
    portfolio: "",
  },
};

// =====================================================
// HELPERS
// =====================================================

const normalizeProfileToForm = (profile) => {
  if (!profile) {
    return emptyForm;
  }

  return {
    phone: profile.phone || "",
    headline: profile.headline || "",
    about: profile.about || "",
    location: profile.location || "",

    skills: Array.isArray(profile.skills) ? profile.skills : [],

    experience: Array.isArray(profile.experience)
      ? profile.experience.map((item) => ({
          company: item.company || "",
          position: item.position || "",
          startDate: item.startDate ? item.startDate.substring(0, 10) : "",
          endDate: item.endDate ? item.endDate.substring(0, 10) : "",
          isCurrent: Boolean(item.isCurrent),
          location: item.location || "",
          description: item.description || "",
        }))
      : [],

    education: Array.isArray(profile.education)
      ? profile.education.map((item) => ({
          institution: item.institution || "",
          degree: item.degree || "",
          field: item.field || "",
          startDate: item.startDate ? item.startDate.substring(0, 10) : "",
          endDate: item.endDate ? item.endDate.substring(0, 10) : "",
          grade: item.grade || "",
        }))
      : [],

    socialLinks: {
      linkedin: profile.socialLinks?.linkedin || "",
      github: profile.socialLinks?.github || "",
      portfolio: profile.socialLinks?.portfolio || "",
    },
  };
};

const cleanOptionalValue = (value) => {
  const trimmed = value?.trim?.() || "";

  return trimmed || undefined;
};

// =====================================================
// COMPONENT
// =====================================================

const RecruiterProfile = () => {
  const dispatch = useDispatch();

  const {
    profile,
    profileLoading,
    profileError,
    isSubmitting,
    successMessage,
  } = useSelector((state) => state.recruiter);

  const [isEditing, setIsEditing] = useState(false);

  const [formData, setFormData] = useState(emptyForm);

  const [skillInput, setSkillInput] = useState("");

  // ===================================================
  // FETCH PROFILE
  // ===================================================

  useEffect(() => {
    dispatch(fetchRecruiterProfile());
  }, [dispatch]);

  // ===================================================
  // WHEN PROFILE CHANGES
  // ===================================================

  useEffect(() => {
    if (profile) {
      setFormData(normalizeProfileToForm(profile));
      setIsEditing(false);
    } else if (profile === null) {
      setFormData(emptyForm);
      setIsEditing(true);
    }
  }, [profile]);

  // ===================================================
  // SUCCESS
  // ===================================================

  useEffect(() => {
    if (!successMessage) {
      return;
    }

    const timer = setTimeout(() => {
      dispatch(clearRecruiterSuccess());
    }, 3000);

    return () => clearTimeout(timer);
  }, [successMessage, dispatch]);

  // ===================================================
  // FORM CHANGE
  // ===================================================

  const handleChange = (event) => {
    const { name, value } = event.target;

    setFormData((previous) => ({
      ...previous,
      [name]: value,
    }));
  };

  // ===================================================
  // SOCIAL CHANGE
  // ===================================================

  const handleSocialChange = (event) => {
    const { name, value } = event.target;

    setFormData((previous) => ({
      ...previous,

      socialLinks: {
        ...previous.socialLinks,
        [name]: value,
      },
    }));
  };

  // ===================================================
  // SKILLS
  // ===================================================

  const addSkill = () => {
    const skill = skillInput.trim();

    if (!skill) {
      return;
    }

    const alreadyExists = formData.skills.some(
      (item) => item.toLowerCase() === skill.toLowerCase(),
    );

    if (alreadyExists) {
      setSkillInput("");
      return;
    }

    if (skill.length > 50) {
      return;
    }

    setFormData((previous) => ({
      ...previous,
      skills: [...previous.skills, skill],
    }));

    setSkillInput("");
  };

  const handleSkillKeyDown = (event) => {
    if (event.key === "Enter") {
      event.preventDefault();
      addSkill();
    }
  };

  const removeSkill = (index) => {
    setFormData((previous) => ({
      ...previous,
      skills: previous.skills.filter((_, skillIndex) => skillIndex !== index),
    }));
  };

  // ===================================================
  // EXPERIENCE
  // ===================================================

  const addExperience = () => {
    setFormData((previous) => ({
      ...previous,

      experience: [
        ...previous.experience,
        {
          company: "",
          position: "",
          startDate: "",
          endDate: "",
          isCurrent: false,
          location: "",
          description: "",
        },
      ],
    }));
  };

  const removeExperience = (index) => {
    setFormData((previous) => ({
      ...previous,

      experience: previous.experience.filter(
        (_, itemIndex) => itemIndex !== index,
      ),
    }));
  };

  const handleExperienceChange = (index, field, value) => {
    setFormData((previous) => ({
      ...previous,

      experience: previous.experience.map((item, itemIndex) => {
        if (itemIndex !== index) {
          return item;
        }

        if (field === "isCurrent") {
          return {
            ...item,
            isCurrent: value,
            endDate: value ? "" : item.endDate,
          };
        }

        return {
          ...item,
          [field]: value,
        };
      }),
    }));
  };

  // ===================================================
  // EDUCATION
  // ===================================================

  const addEducation = () => {
    setFormData((previous) => ({
      ...previous,

      education: [
        ...previous.education,
        {
          institution: "",
          degree: "",
          field: "",
          startDate: "",
          endDate: "",
          grade: "",
        },
      ],
    }));
  };

  const removeEducation = (index) => {
    setFormData((previous) => ({
      ...previous,

      education: previous.education.filter(
        (_, itemIndex) => itemIndex !== index,
      ),
    }));
  };

  const handleEducationChange = (index, field, value) => {
    setFormData((previous) => ({
      ...previous,

      education: previous.education.map((item, itemIndex) =>
        itemIndex === index
          ? {
              ...item,
              [field]: value,
            }
          : item,
      ),
    }));
  };

  // ===================================================
  // PAYLOAD
  // ===================================================

  const buildPayload = () => {
    return {
      phone: cleanOptionalValue(formData.phone),

      headline: cleanOptionalValue(formData.headline),

      about: cleanOptionalValue(formData.about),

      location: cleanOptionalValue(formData.location),

      skills: formData.skills.map((skill) => skill.trim()).filter(Boolean),

      experience: formData.experience
        .filter(
          (item) =>
            item.company.trim() || item.position.trim() || item.startDate,
        )
        .map((item) => {
          const experience = {
            company: item.company.trim(),
            position: item.position.trim(),
            startDate: item.startDate,

            location: cleanOptionalValue(item.location),

            description: cleanOptionalValue(item.description),

            isCurrent: Boolean(item.isCurrent),
          };

          if (!item.isCurrent && item.endDate) {
            experience.endDate = item.endDate;
          }

          return experience;
        }),

      education: formData.education
        .filter((item) => item.institution.trim() || item.degree.trim())
        .map((item) => ({
          institution: item.institution.trim(),
          degree: item.degree.trim(),

          field: cleanOptionalValue(item.field),

          startDate: cleanOptionalValue(item.startDate),

          endDate: cleanOptionalValue(item.endDate),

          grade: cleanOptionalValue(item.grade),
        })),

      socialLinks: {
        linkedin: cleanOptionalValue(formData.socialLinks.linkedin),

        github: cleanOptionalValue(formData.socialLinks.github),

        portfolio: cleanOptionalValue(formData.socialLinks.portfolio),
      },
    };
  };

  // ===================================================
  // SUBMIT
  // ===================================================

  const handleSubmit = async (event) => {
    event.preventDefault();

    dispatch(clearRecruiterError());

    const payload = buildPayload();

    try {
      if (profile) {
        await dispatch(updateRecruiterProfile(payload)).unwrap();
      } else {
        await dispatch(createRecruiterProfile(payload)).unwrap();
      }

      setIsEditing(false);
    } catch (error) {
      console.error("Profile submission failed:", error);
    }
  };

  // ===================================================
  // CANCEL EDIT
  // ===================================================

  const handleCancel = () => {
    if (profile) {
      setFormData(normalizeProfileToForm(profile));
      setIsEditing(false);
    } else {
      setFormData(emptyForm);
    }

    dispatch(clearRecruiterError());
  };

  // ===================================================
  // COMPLETION
  // ===================================================

  const completion = useMemo(() => {
    return profile?.profileCompletion || 0;
  }, [profile]);

  // ===================================================
  // LOADING
  // ===================================================

  if (profileLoading) {
    return (
      <div className="recruiter-profile-page">
        <div className="recruiter-profile-loading">
          <div className="recruiter-profile-spinner" />
          <p>Loading profile...</p>
        </div>
      </div>
    );
  }

  // ===================================================
  // RENDER
  // ===================================================

  return (
    <div className="recruiter-profile-page">
      {/* =================================================
          HEADER
      ================================================= */}

      <div className="recruiter-page-header">
        <div>
          <span className="recruiter-page-eyebrow">Recruiter</span>

          <h1>{profile ? "Recruiter Profile" : "Create Your Profile"}</h1>

          <p>
            Build a professional profile to represent yourself and your
            organization.
          </p>
        </div>

        {profile && !isEditing && (
          <button
            type="button"
            className="recruiter-primary-button"
            onClick={() => setIsEditing(true)}
          >
            Edit Profile
          </button>
        )}
      </div>

      {/* =================================================
          ERROR
      ================================================= */}

      {profileError && (
        <div className="recruiter-alert recruiter-alert-error">
          <span>{profileError}</span>

          <button type="button" onClick={() => dispatch(clearRecruiterError())}>
            ×
          </button>
        </div>
      )}

      {/* =================================================
          SUCCESS
      ================================================= */}

      {successMessage && (
        <div className="recruiter-alert recruiter-alert-success">
          {successMessage}
        </div>
      )}

      {/* =================================================
          PROFILE IDENTITY
      ================================================= */}

      {profile && (
        <section className="recruiter-profile-identity-card">
          <div className="recruiter-profile-avatar">
            {profile.user?.avatar ? (
              <img
                src={profile.user.avatar}
                alt={profile.user?.name || "Recruiter"}
              />
            ) : (
              <span>{profile.user?.name?.charAt(0)?.toUpperCase() || "R"}</span>
            )}
          </div>

          <div className="recruiter-profile-identity">
            <h2>{profile.user?.name || "Recruiter"}</h2>

            <p className="recruiter-profile-headline">
              {profile.headline || "Recruiter profile"}
            </p>

            <div className="recruiter-profile-meta">
              {profile.user?.email && <span>{profile.user.email}</span>}

              {profile.location && <span>{profile.location}</span>}

              {profile.user?.isEmailVerified && (
                <span className="recruiter-verified">Email verified</span>
              )}
            </div>
          </div>

          <div className="recruiter-profile-completion">
            <div className="completion-header">
              <span>Profile completion</span>
              <strong>{completion}%</strong>
            </div>

            <div className="completion-track">
              <div
                className="completion-progress"
                style={{
                  width: `${completion}%`,
                }}
              />
            </div>
          </div>
        </section>
      )}

      {/* =================================================
          CREATE / EDIT FORM
      ================================================= */}

      {isEditing ? (
        <form className="recruiter-profile-form" onSubmit={handleSubmit}>
          {/* =================================================
              PROFESSIONAL INFORMATION
          ================================================= */}

          <section className="recruiter-profile-section">
            <div className="section-heading">
              <div>
                <h2>Professional Information</h2>
                <p>
                  Add the information candidates and companies should know about
                  you.
                </p>
              </div>
            </div>

            <div className="profile-form-grid">
              <div className="profile-field">
                <label htmlFor="phone">Phone</label>

                <input
                  id="phone"
                  name="phone"
                  type="tel"
                  value={formData.phone}
                  onChange={handleChange}
                  placeholder="+91 9876543210"
                  maxLength={20}
                />
              </div>

              <div className="profile-field">
                <label htmlFor="location">Location</label>

                <input
                  id="location"
                  name="location"
                  type="text"
                  value={formData.location}
                  onChange={handleChange}
                  placeholder="Bhopal, Madhya Pradesh"
                  maxLength={150}
                />
              </div>

              <div className="profile-field profile-field-full">
                <label htmlFor="headline">Professional Headline</label>

                <input
                  id="headline"
                  name="headline"
                  type="text"
                  value={formData.headline}
                  onChange={handleChange}
                  placeholder="Talent Acquisition Specialist | Tech Recruiter"
                  maxLength={150}
                />

                <small>{formData.headline.length}/150</small>
              </div>

              <div className="profile-field profile-field-full">
                <label htmlFor="about">About</label>

                <textarea
                  id="about"
                  name="about"
                  value={formData.about}
                  onChange={handleChange}
                  placeholder="Tell candidates about your recruiting experience and specialization..."
                  rows={6}
                  maxLength={3000}
                />

                <small>{formData.about.length}/3000</small>
              </div>
            </div>
          </section>

          {/* =================================================
              SKILLS
          ================================================= */}

          <section className="recruiter-profile-section">
            <div className="section-heading">
              <div>
                <h2>Recruiting Skills</h2>
                <p>Add the skills that describe your recruiting expertise.</p>
              </div>
            </div>

            <div className="skill-input-row">
              <input
                type="text"
                value={skillInput}
                onChange={(event) => setSkillInput(event.target.value)}
                onKeyDown={handleSkillKeyDown}
                placeholder="e.g. Talent Acquisition"
                maxLength={50}
              />

              <button
                type="button"
                className="recruiter-secondary-button"
                onClick={addSkill}
              >
                Add Skill
              </button>
            </div>

            {formData.skills.length > 0 && (
              <div className="profile-skill-list">
                {formData.skills.map((skill, index) => (
                  <span className="profile-skill-tag" key={`${skill}-${index}`}>
                    {skill}

                    <button
                      type="button"
                      onClick={() => removeSkill(index)}
                      aria-label={`Remove ${skill}`}
                    >
                      ×
                    </button>
                  </span>
                ))}
              </div>
            )}
          </section>

          {/* =================================================
              EXPERIENCE
          ================================================= */}

          <section className="recruiter-profile-section">
            <div className="section-heading section-heading-with-action">
              <div>
                <h2>Professional Experience</h2>
                <p>Add your previous recruiting and professional experience.</p>
              </div>

              <button
                type="button"
                className="recruiter-secondary-button"
                onClick={addExperience}
              >
                + Add Experience
              </button>
            </div>

            {formData.experience.length === 0 ? (
              <div className="profile-empty-section">
                <p>No experience added yet.</p>
              </div>
            ) : (
              <div className="profile-repeat-list">
                {formData.experience.map((experience, index) => (
                  <div className="profile-repeat-card" key={index}>
                    <div className="repeat-card-header">
                      <h3>Experience #{index + 1}</h3>

                      <button
                        type="button"
                        className="danger-text-button"
                        onClick={() => removeExperience(index)}
                      >
                        Remove
                      </button>
                    </div>

                    <div className="profile-form-grid">
                      <div className="profile-field">
                        <label>Company *</label>

                        <input
                          type="text"
                          value={experience.company}
                          onChange={(event) =>
                            handleExperienceChange(
                              index,
                              "company",
                              event.target.value,
                            )
                          }
                          placeholder="Company name"
                        />
                      </div>

                      <div className="profile-field">
                        <label>Position *</label>

                        <input
                          type="text"
                          value={experience.position}
                          onChange={(event) =>
                            handleExperienceChange(
                              index,
                              "position",
                              event.target.value,
                            )
                          }
                          placeholder="Talent Acquisition Specialist"
                        />
                      </div>

                      <div className="profile-field">
                        <label>Start Date *</label>

                        <input
                          type="date"
                          value={experience.startDate}
                          onChange={(event) =>
                            handleExperienceChange(
                              index,
                              "startDate",
                              event.target.value,
                            )
                          }
                        />
                      </div>

                      <div className="profile-field">
                        <label>End Date</label>

                        <input
                          type="date"
                          value={experience.endDate}
                          disabled={experience.isCurrent}
                          onChange={(event) =>
                            handleExperienceChange(
                              index,
                              "endDate",
                              event.target.value,
                            )
                          }
                        />
                      </div>

                      <div className="profile-field">
                        <label>Location</label>

                        <input
                          type="text"
                          value={experience.location}
                          onChange={(event) =>
                            handleExperienceChange(
                              index,
                              "location",
                              event.target.value,
                            )
                          }
                          placeholder="Bengaluru, India"
                        />
                      </div>

                      <div className="profile-field profile-checkbox-field">
                        <label>
                          <input
                            type="checkbox"
                            checked={experience.isCurrent}
                            onChange={(event) =>
                              handleExperienceChange(
                                index,
                                "isCurrent",
                                event.target.checked,
                              )
                            }
                          />
                          Currently working here
                        </label>
                      </div>

                      <div className="profile-field profile-field-full">
                        <label>Description</label>

                        <textarea
                          rows={4}
                          value={experience.description}
                          onChange={(event) =>
                            handleExperienceChange(
                              index,
                              "description",
                              event.target.value,
                            )
                          }
                          placeholder="Describe your responsibilities and achievements..."
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>

          {/* =================================================
              EDUCATION
          ================================================= */}

          <section className="recruiter-profile-section">
            <div className="section-heading section-heading-with-action">
              <div>
                <h2>Education</h2>
                <p>Add your educational background.</p>
              </div>

              <button
                type="button"
                className="recruiter-secondary-button"
                onClick={addEducation}
              >
                + Add Education
              </button>
            </div>

            {formData.education.length === 0 ? (
              <div className="profile-empty-section">
                <p>No education added yet.</p>
              </div>
            ) : (
              <div className="profile-repeat-list">
                {formData.education.map((education, index) => (
                  <div className="profile-repeat-card" key={index}>
                    <div className="repeat-card-header">
                      <h3>Education #{index + 1}</h3>

                      <button
                        type="button"
                        className="danger-text-button"
                        onClick={() => removeEducation(index)}
                      >
                        Remove
                      </button>
                    </div>

                    <div className="profile-form-grid">
                      <div className="profile-field">
                        <label>Institution *</label>

                        <input
                          type="text"
                          value={education.institution}
                          onChange={(event) =>
                            handleEducationChange(
                              index,
                              "institution",
                              event.target.value,
                            )
                          }
                          placeholder="University / College"
                        />
                      </div>

                      <div className="profile-field">
                        <label>Degree *</label>

                        <input
                          type="text"
                          value={education.degree}
                          onChange={(event) =>
                            handleEducationChange(
                              index,
                              "degree",
                              event.target.value,
                            )
                          }
                          placeholder="B.Tech"
                        />
                      </div>

                      <div className="profile-field">
                        <label>Field of Study</label>

                        <input
                          type="text"
                          value={education.field}
                          onChange={(event) =>
                            handleEducationChange(
                              index,
                              "field",
                              event.target.value,
                            )
                          }
                          placeholder="Computer Science"
                        />
                      </div>

                      <div className="profile-field">
                        <label>Grade</label>

                        <input
                          type="text"
                          value={education.grade}
                          onChange={(event) =>
                            handleEducationChange(
                              index,
                              "grade",
                              event.target.value,
                            )
                          }
                          placeholder="8.5 CGPA"
                        />
                      </div>

                      <div className="profile-field">
                        <label>Start Date</label>

                        <input
                          type="date"
                          value={education.startDate}
                          onChange={(event) =>
                            handleEducationChange(
                              index,
                              "startDate",
                              event.target.value,
                            )
                          }
                        />
                      </div>

                      <div className="profile-field">
                        <label>End Date</label>

                        <input
                          type="date"
                          value={education.endDate}
                          onChange={(event) =>
                            handleEducationChange(
                              index,
                              "endDate",
                              event.target.value,
                            )
                          }
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>

          {/* =================================================
              SOCIAL LINKS
          ================================================= */}

          <section className="recruiter-profile-section">
            <div className="section-heading">
              <div>
                <h2>Professional Links</h2>
                <p>Add links to your professional profiles.</p>
              </div>
            </div>

            <div className="profile-form-grid">
              <div className="profile-field">
                <label>LinkedIn</label>

                <input
                  type="url"
                  name="linkedin"
                  value={formData.socialLinks.linkedin}
                  onChange={handleSocialChange}
                  placeholder="https://linkedin.com/in/yourname"
                />
              </div>

              <div className="profile-field">
                <label>GitHub</label>

                <input
                  type="url"
                  name="github"
                  value={formData.socialLinks.github}
                  onChange={handleSocialChange}
                  placeholder="https://github.com/yourname"
                />
              </div>

              <div className="profile-field profile-field-full">
                <label>Portfolio</label>

                <input
                  type="url"
                  name="portfolio"
                  value={formData.socialLinks.portfolio}
                  onChange={handleSocialChange}
                  placeholder="https://yourportfolio.com"
                />
              </div>
            </div>
          </section>

          {/* =================================================
              FORM ACTIONS
          ================================================= */}

          <div className="recruiter-profile-form-actions">
            {profile && (
              <button
                type="button"
                className="recruiter-cancel-button"
                onClick={handleCancel}
                disabled={isSubmitting}
              >
                Cancel
              </button>
            )}

            <button
              type="submit"
              className="recruiter-primary-button"
              disabled={isSubmitting}
            >
              {isSubmitting
                ? profile
                  ? "Saving..."
                  : "Creating..."
                : profile
                  ? "Save Changes"
                  : "Create Profile"}
            </button>
          </div>
        </form>
      ) : (
        /* =================================================
           VIEW MODE
        ================================================= */

        <div className="recruiter-profile-view">
          {/* ABOUT */}

          <section className="recruiter-profile-section">
            <div className="section-heading">
              <div>
                <h2>About</h2>
              </div>
            </div>

            <p className="profile-about-text">
              {profile?.about || "No professional summary added yet."}
            </p>
          </section>

          {/* SKILLS */}

          <section className="recruiter-profile-section">
            <div className="section-heading">
              <div>
                <h2>Skills</h2>
              </div>
            </div>

            {profile?.skills?.length > 0 ? (
              <div className="profile-skill-list">
                {profile.skills.map((skill, index) => (
                  <span
                    className="profile-skill-tag profile-skill-readonly"
                    key={`${skill}-${index}`}
                  >
                    {skill}
                  </span>
                ))}
              </div>
            ) : (
              <p className="profile-muted-text">No skills added yet.</p>
            )}
          </section>

          {/* EXPERIENCE */}

          <section className="recruiter-profile-section">
            <div className="section-heading">
              <div>
                <h2>Professional Experience</h2>
              </div>
            </div>

            {profile?.experience?.length > 0 ? (
              <div className="profile-view-list">
                {profile.experience.map((experience, index) => (
                  <article className="profile-view-item" key={index}>
                    <div className="profile-view-item-top">
                      <div>
                        <h3>{experience.position}</h3>

                        <p>{experience.company}</p>
                      </div>

                      <span>
                        {experience.startDate
                          ? new Date(experience.startDate).toLocaleDateString(
                              "en-IN",
                              {
                                month: "short",
                                year: "numeric",
                              },
                            )
                          : ""}

                        {" — "}

                        {experience.isCurrent
                          ? "Present"
                          : experience.endDate
                            ? new Date(experience.endDate).toLocaleDateString(
                                "en-IN",
                                {
                                  month: "short",
                                  year: "numeric",
                                },
                              )
                            : ""}
                      </span>
                    </div>

                    {experience.location && (
                      <p className="profile-item-location">
                        {experience.location}
                      </p>
                    )}

                    {experience.description && (
                      <p className="profile-item-description">
                        {experience.description}
                      </p>
                    )}
                  </article>
                ))}
              </div>
            ) : (
              <p className="profile-muted-text">No experience added yet.</p>
            )}
          </section>

          {/* EDUCATION */}

          <section className="recruiter-profile-section">
            <div className="section-heading">
              <div>
                <h2>Education</h2>
              </div>
            </div>

            {profile?.education?.length > 0 ? (
              <div className="profile-view-list">
                {profile.education.map((education, index) => (
                  <article className="profile-view-item" key={index}>
                    <div className="profile-view-item-top">
                      <div>
                        <h3>{education.degree}</h3>

                        <p>{education.institution}</p>
                      </div>

                      {education.grade && <span>{education.grade}</span>}
                    </div>

                    {education.field && (
                      <p className="profile-item-location">{education.field}</p>
                    )}
                  </article>
                ))}
              </div>
            ) : (
              <p className="profile-muted-text">No education added yet.</p>
            )}
          </section>

          {/* LINKS */}

          <section className="recruiter-profile-section">
            <div className="section-heading">
              <div>
                <h2>Professional Links</h2>
              </div>
            </div>

            <div className="profile-links">
              {profile?.socialLinks?.linkedin && (
                <a
                  href={profile.socialLinks.linkedin}
                  target="_blank"
                  rel="noreferrer"
                >
                  LinkedIn
                </a>
              )}

              {profile?.socialLinks?.github && (
                <a
                  href={profile.socialLinks.github}
                  target="_blank"
                  rel="noreferrer"
                >
                  GitHub
                </a>
              )}

              {profile?.socialLinks?.portfolio && (
                <a
                  href={profile.socialLinks.portfolio}
                  target="_blank"
                  rel="noreferrer"
                >
                  Portfolio
                </a>
              )}

              {!profile?.socialLinks?.linkedin &&
                !profile?.socialLinks?.github &&
                !profile?.socialLinks?.portfolio && (
                  <p className="profile-muted-text">
                    No professional links added yet.
                  </p>
                )}
            </div>
          </section>
        </div>
      )}
    </div>
  );
};

export default RecruiterProfile;
