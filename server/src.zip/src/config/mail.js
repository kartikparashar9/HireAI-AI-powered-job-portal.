import nodemailer from "nodemailer";
import env from "./env.js";

const transporter = nodemailer.createTransport({
  host: env.smtp.host,
  port: env.smtp.port,
  secure: env.smtp.port === 465,

  auth: {
    user: env.smtp.user,
    pass: env.smtp.password,
  },
});

export default transporter;
;