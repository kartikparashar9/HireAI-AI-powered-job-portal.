Job tests placeholder
